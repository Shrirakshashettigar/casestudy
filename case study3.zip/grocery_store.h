// grocery_store.h
#ifndef GROCERY_STORE_H
#define GROCERY_STORE_H

#define NUM_ITEMS 8

// Declare grocery item names and prices
extern const char* GroceryItemNames[NUM_ITEMS];
extern float itemPrices[NUM_ITEMS];

// Structure to hold customer details
struct Customer {
    char name[50];
    char address[100];
    char phone[15];
};

// Structure to hold login information
struct LoginInfo {
    char username[20];
    char password[20];
};

// Function prototypes
void displayMenu();
void getCustomerDetails(struct Customer *customer);
int matchItemName(const char *itemName);
int login(struct LoginInfo *loginInfo);
void saveToFile(struct Customer *customer, int quantities[]);
void searchCustomerData(const char *name);

#endif // GROCERY_STORE_H
