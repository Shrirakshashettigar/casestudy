#ifndef CUSTOMER_DETAILS_H
#define CUSTOMER_DETAILS_H

void getCustomerDetails(char name[], char address[], char phone[]);

#endif 
