#ifndef MENU_H
#define MENU_H

#define NUM_ITEMS 8

enum GroceryItem {
    RICE, PASTA, MILK, EGGS, BREAD, CHEESE, CHICKEN, FISH
};

extern const char* GroceryItemNames[NUM_ITEMS];
extern float itemPrices[NUM_ITEMS];

void displayMenu();

#endif 
