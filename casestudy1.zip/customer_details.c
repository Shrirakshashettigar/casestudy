#include "customer_details.h"
#include <stdio.h>
#include <string.h>

void getCustomerDetails(char name[], char address[], char phone[]) {
    printf("Enter your name: ");
    scanf("%s", name);
    printf("Enter your address: ");
    scanf(" %[^\n]", address);

    while (1) {
        printf("Enter your phone number: ");
        scanf("%s", phone);
        if (strlen(phone) < 10) {
            printf("Invalid phone number. Please enter a valid phone number with at least 10 digits.\n");
        } else {
            break;
        }
    }
}
