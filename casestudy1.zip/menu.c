#include "menu.h"
#include <stdio.h>

const char* GroceryItemNames[NUM_ITEMS] = {
    "Rice", "Pasta", "Milk", "Eggs", "Bread",
    "Cheese", "Chicken", "Fish"
};

float itemPrices[NUM_ITEMS] = {60.0, 45.5, 25.75, 20.25, 30.0, 55.0, 150.0, 40.0};

#define PRINT_ITEM(item) printf("%d. %s - %.2f rupees/unit\n", item + 1, GroceryItemNames[item], itemPrices[item])

void displayMenu() {
    printf("Welcome to the grocery store!\nMenu:\n");
    for (int i = 0; i < NUM_ITEMS; ++i) {
        PRINT_ITEM(i);
    }
}
