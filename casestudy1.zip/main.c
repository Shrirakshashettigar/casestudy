#include <stdio.h>
#include "menu.h"
#include "customer_details.h"

#define NUM_ITEMS 8

int main() {
    char name[50], address[100], phone[15];
    int quantities[NUM_ITEMS] = {0};
    int choice, quantity;

    getCustomerDetails(name, address, phone);

    displayMenu();

    printf("\nEnter the item number and quantity in units (0 to finish):\n");
    while (1) {
        printf("Item number: ");
        scanf("%d", &choice);
        if (choice <= 0 || choice > NUM_ITEMS)
            break;
        printf("Quantity in units: ");
        scanf("%d", &quantity);
        if (quantity < 0) {
            printf("Invalid quantity. Please enter a non-negative value.\n");
            continue;
        }
        quantities[choice - 1] += quantity;
    }

    printf("\nCustomer Name: %s\nAddress: %s\nPhone Number: %s\nItems purchased:\n", name, address, phone);
    for (int i = 0; i < NUM_ITEMS; ++i) {
        if (quantities[i] > 0) {
            printf("- %d units of %s\n", quantities[i], GroceryItemNames[i]);
        }
    }

    return 0;
}
